package com.example.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.Entity.PolicyEntity;
import com.example.bean.PolicyBean;

@Repository
@Transactional
public interface PolicyDao {
	public PolicyEntity createPolicy(PolicyBean policyBean);

	public PolicyEntity searchPolicyById(Long policyNo);

	public void deletePolicy(Long policyNo);

	public PolicyEntity updatePolicy(Long policyNo, PolicyBean policyBean);

	public List<PolicyEntity> readPolicy();

}
