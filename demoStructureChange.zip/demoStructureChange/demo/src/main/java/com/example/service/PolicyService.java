package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.Entity.PolicyEntity;
import com.example.bean.PolicyBean;

@Service
public interface PolicyService {

	public PolicyEntity createPolicy(PolicyBean policyBean);

	public PolicyEntity searchPolicyById(Long policyNo);

	public void deleteCustomer(Long policyNo);

	public PolicyEntity updatePolicy(Long policyNo, PolicyBean policyBean);

	public List<PolicyEntity> readPolicy();

}