package com.example.controller;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.PolicyEntity;
import com.example.bean.PolicyBean;
import com.example.service.PolicyService;

@RestController
@RequestMapping("/api")
public class PolicyController {

	@Autowired
	PolicyService _policyService;

	@RequestMapping(value = "/policy/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchPolicyById(@PathVariable("id") Long policyNo) {
		PolicyEntity policyEntity = _policyService.searchPolicyById(policyNo);

		return new ResponseEntity<Object>(policyEntity, HttpStatus.FOUND);

		// try {
		// PolicyEntity policy = _policyService.getPolicyById(policyNo);
		// if (policy != null) {
		// return new ResponseEntity<Object>("Policy not found with policy no "
		// + policyNo + " in the database",
		// HttpStatus.NOT_FOUND);
		//
		// } else {
		// // return new ResponseEntity<Object>(policy,HttpStatus.FOUND);
		// throw new PolicyNotFoundException("Policy not found with id " +
		// policyNo);
		// }
		// } catch (Exception e) {
		// throw new DatabaseExcepiton("Database Error");
		// }
	}

	@RequestMapping(value = "/policy", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<PolicyEntity>> readData() {
		System.out.println("//////////////");
		List<PolicyEntity> policyEntityList = _policyService.readPolicy();
		System.out.println("//////////////");
		return new ResponseEntity<Collection<PolicyEntity>>(policyEntityList, HttpStatus.OK);

		// List<PolicyEntity> policyList = new ArrayList<PolicyEntity>();
		// try {
		// policyList = _policyService.selectAll();
		// if (policyList == null) {
		// throw new PolicyNotFoundException("No Data in database");
		// } else {
		// return new ResponseEntity<Collection<PolicyEntity>>(policyList,
		// HttpStatus.OK);
		// }
		// } catch (Exception e) {
		// throw new DatabaseExcepiton("Database Error");
		// }

	}

	@RequestMapping(value = "/policy/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> delete(@PathVariable("id") Long policyNo) {
		_policyService.deleteCustomer(policyNo);
		return new ResponseEntity<Object>("Deleted with policy  with no " + policyNo + " successfully",
				HttpStatus.NO_CONTENT);

		// PolicyEntity policy = null;
		// try {
		//
		// policy = _policyService.getPolicyById(policyNo);
		// if (policy != null) {
		// _policyService.delete(policyNo);
		// return new ResponseEntity<Object>("Deleted with policy with no " +
		// policyNo + " successfully",
		// HttpStatus.NO_CONTENT);
		// } else {
		// // return new ResponseEntity<Object>("Unable to delted customer
		// // with id " + customerId + " not found",
		// // HttpStatus.NOT_FOUND);
		// throw new PolicyNotFoundException("No Data in database");
		//
		// }
		// } catch (Exception e) {
		// throw new DatabaseExcepiton("Database Error");
		// }

	}

	@RequestMapping(value = "/policy/{id}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> update(@PathVariable("id") Long policyNo, @RequestBody PolicyBean policyBean) {
		PolicyEntity policyEntity = _policyService.updatePolicy(policyNo, policyBean);
		return new ResponseEntity<Object>(policyEntity, HttpStatus.OK);

		// PolicyEntity policySearch = null;
		// try {
		// policySearch = _policyService.getPolicyById(policyNo);
		// if (policySearch == null) {
		// throw new PolicyNotFoundException("Policy Not Found");
		// } else {
		// policySearch.setApplicationType(policy.getApplicationType());
		// policySearch.setCoverage(policy.getCoverage());
		// policySearch.setCustomerName(policy.getCustomerName());
		// policySearch.setCustomerNumber(policy.getCustomerNumber());
		// policySearch.setLRV(policy.getLRV());
		// policySearch.setPaymentPlan(policy.getPaymentPlan());
		// policySearch.setStatus(policy.getStatus());
		// policySearch.setTerminationReason(policy.getTerminationReason());
		// policySearch.setTerminationType(policy.getTerminationType());
		//
		// PolicyEntity policysaved = _policyService.save(policySearch);
		// return new ResponseEntity<Object>(policysaved, HttpStatus.OK);
		// }
		//
		// } catch (Exception e) {
		// throw new DatabaseExcepiton("Database Error");
		// }

	}
	
	@RequestMapping(value="/policy", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PolicyEntity> createPolicy(@RequestBody PolicyBean policyBean){
		PolicyEntity policyEntity = _policyService.createPolicy(policyBean);
		return new ResponseEntity<PolicyEntity>(policyEntity,HttpStatus.CREATED);
		
	}

}
