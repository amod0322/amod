package com.example.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.Entity.CustomerEntity;
import com.example.bean.CustomerBean;

@Repository
@Transactional
public interface CustomerDao {
	public CustomerEntity createCustomer(CustomerBean customer);

	public CustomerEntity searchCustomerById(Long customerId);

	public void deleteCustomer(Long customerId);

	public CustomerEntity updateCustomer(Long customerId, CustomerBean customeBean);

	public List<CustomerEntity> readCustomer();
}