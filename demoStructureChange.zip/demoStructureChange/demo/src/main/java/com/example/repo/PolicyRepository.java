package com.example.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Entity.PolicyEntity;

@Repository
@Transactional
public interface PolicyRepository extends JpaRepository<PolicyEntity, Long> {

}
