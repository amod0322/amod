package com.archcap.party.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.archcap.party.bc.PartyBean;
import com.archcap.party.entity.PartyEntity;

@Repository
@Transactional
public interface PartyDao {
	
	public PartyEntity createParty(PartyBean partyBean);

	public PartyEntity searchPartyById(Long partyId);

	public void deleteParty(Long partyId);

	public PartyEntity updateParty(Long partyId, PartyBean partyBean);

	public List<PartyEntity> readParty();

}