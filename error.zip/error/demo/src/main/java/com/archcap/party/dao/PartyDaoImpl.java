package com.archcap.party.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.archcap.party.bc.PartyBean;
import com.archcap.party.entity.AddressEntity;
import com.archcap.party.entity.PartyEntity;
import com.archcap.party.entity.RoleEntity;
import com.archcap.party.repository.PartyRepository;
@Repository
@Transactional
public class PartyDaoImpl implements PartyDao {
	
	@Autowired
	 private PartyRepository _partyRepository;

	@Override
	public PartyEntity createParty(PartyBean partyBean) {
		PartyEntity partyEntity = new PartyEntity();
		partyEntity.setPartyName(partyBean.getPartyBasicInformation().getPartyName());
		partyEntity.setPartyNickName(partyBean.getPartyBasicInformation().getNickName());
		partyEntity.setPartyStatus(partyBean.getPartyBasicInformation().getPartyStatus());
		partyEntity.setPartyType(partyBean.getPartyBasicInformation().getPartyType());
		partyEntity.setPartyReferenceId(partyBean.getPartyOptionalInformation().getPartyRefId());
		partyEntity.setArchLMIReferenceId(partyBean.getPartyOptionalInformation().getArchLMIRefId());
		
		
		Set<RoleEntity> roleEntitySet = new HashSet<RoleEntity>();
		for (String roles : partyBean.getPartyRoles().getPartyRoles()) {
			RoleEntity roleEntity = new RoleEntity();
			roleEntity.setLong_name(roles);
			roleEntity.setShort_name(roles);
			roleEntitySet.add(roleEntity);
			
		}
		
		partyEntity.setPartyRoles(roleEntitySet);
		
		
		
		
		
		AddressEntity addressEntity = new AddressEntity();
		addressEntity.setAddressType(partyBean.getAddress().getType());
		addressEntity.setAddressAttn(partyBean.getAddress().getAttn());
		addressEntity.setAddressLine1(partyBean.getAddress().getAddressLine1());
		addressEntity.setAddressLine2(partyBean.getAddress().getAddressLine2());
		addressEntity.setAddressCity(partyBean.getAddress().getCity());
		addressEntity.setAddressState(partyBean.getAddress().getState());
		addressEntity.setAddressPostalCode(partyBean.getAddress().getPostCode());
		addressEntity.setAddressCountry(partyBean.getAddress().getCountry());
		
		partyEntity.setPartyAddress(addressEntity);
		
		PartyEntity savedPartyEntity= _partyRepository.save(partyEntity);
	
		return savedPartyEntity;
	}

	@Override
	public PartyEntity searchPartyById(Long partyId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteParty(Long partyId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public PartyEntity updateParty(Long partyId, PartyBean partyBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PartyEntity> readParty() {
		// TODO Auto-generated method stub
		return null;
	}

}
