package com.archcap.party.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "ROLES")
public class RoleEntity {
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	@Column(name = "ROLE_TYPE_ID")
//	private Long role_type_id;

	@NotEmpty
	@Column(name = "SHORT_NAME", nullable = false)
	private String short_name;

	@Id
	@Column(name = "LONG_NAME", nullable = false)
	private String long_name;
//
//	public Long getRole_type_id() {
//		return role_type_id;
//	}
//
//	public void setRole_type_id(Long role_type_id) {
//		this.role_type_id = role_type_id;
//	}

	public String getShort_name() {
		return short_name;
	}

	public void setShort_name(String short_name) {
		this.short_name = short_name;
	}

	public String getLong_name() {
		return long_name;
	}

	public void setLong_name(String long_name) {
		this.long_name = long_name;
	}

}
