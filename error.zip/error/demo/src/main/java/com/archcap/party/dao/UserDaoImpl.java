package com.archcap.party.dao;
/*package com.example.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.model.User;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {
	
	@Autowired
	private SessionFactory _sessionFactory;
	
	@Override
	public void save(User user){
		_sessionFactory.getCurrentSession().save(user);
	}
	
	@Override
	public void delete(User user) {
		_sessionFactory.getCurrentSession().delete(user);
		return;
	}
	
	@Override
	public void update(User user) {
		_sessionFactory.getCurrentSession().update(user);
		return;
	}
	
	@Override
	public User getUserById(Long id){
		return (User)_sessionFactory.getCurrentSession().get(User.class, id);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<User> getAll(){
		return _sessionFactory.getCurrentSession().createQuery("from User").list();
	}

}
*/