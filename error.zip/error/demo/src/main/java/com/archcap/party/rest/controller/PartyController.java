package com.archcap.party.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.archcap.party.bc.PartyBean;
import com.archcap.party.entity.PartyEntity;
import com.archcap.party.service.PartyService;

@RestController
@RequestMapping("/api")
public class PartyController {
	
	@Autowired
	private PartyService _partyService;
	
	@RequestMapping(value = "/party", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PartyEntity> createParty(@RequestBody PartyBean partyBean) {

		PartyEntity partyEntity = _partyService.createParty(partyBean);

		return new ResponseEntity<PartyEntity>(partyEntity, HttpStatus.CREATED);

	}
	
	
	

}
