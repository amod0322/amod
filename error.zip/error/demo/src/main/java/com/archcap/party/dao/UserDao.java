package com.archcap.party.dao;
/*package com.example.dao;

import java.util.List;

import com.example.model.User;

public interface UserDao {

	void save(User user);
	void delete(User user);
	void update(User user);
	User getUserById(Long id);
	List<User> getAll();

}*/