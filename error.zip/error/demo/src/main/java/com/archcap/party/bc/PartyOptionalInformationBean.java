package com.archcap.party.bc;

public class PartyOptionalInformationBean {
	private String partyRefId;
	private String archLMIRefId;

	public String getPartyRefId() {
		return partyRefId;
	}

	public void setPartyRefId(String partyRefId) {
		this.partyRefId = partyRefId;
	}

	public String getArchLMIRefId() {
		return archLMIRefId;
	}

	public void setArchLMIRefId(String archLMIRefId) {
		this.archLMIRefId = archLMIRefId;
	}

}
