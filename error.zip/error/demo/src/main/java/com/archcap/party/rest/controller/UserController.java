package com.archcap.party.rest.controller;
/*package com.example.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.dao.UserDao;
import com.example.model.User;

@Controller
public class UserController {
	@Autowired
	private UserDao _userDao;

	@RequestMapping("/user")
	public String createUser(String username, String password, @ModelAttribute User user) {
		// User user = new User();
		user.setUsername(username);
		user.setPassword(password);

		_userDao.save(user);

		user.setId(user.getId());

		// return new ModelAndView("forward:/show");
		return "result";

	}
	
	@RequestMapping(value = "/deleteid")
	@ResponseBody
	public String delete(long id) {
		try {
			User user = new User(id);
			_userDao.delete(user);
		} catch (Exception ex) {
			return ex.getMessage();
		}
		return "User succesfully deleted!";
	}
	
	@RequestMapping(value = "/updateid")
	@ResponseBody
	public String update(Long id, String username, String password) {
		User searchUser = _userDao.getUserById(id);
		if (searchUser != null) {
			User user = new User();
			user.setId(id);
			user.setUsername(username);
			user.setPassword(password);
			_userDao.update(user);
			return "User updated successfully";
		}
		return "No Such User Present in Database";

	}
	
	@RequestMapping(value="/read")
	public String readData(Model model){
		List<User> userList = new ArrayList<User>();
		
		userList= _userDao.getAll();
		
		//WebContext ctx = new WebContext(request, response, servletContext, request.getLocale());
	    //ctx.setVariable("objs", userList);
	model.addAttribute(userList);
		return"read";
	}
	

	// @RequestMapping("/show")
	// public String saveSubmit(@ModelAttribute User user) {
	// return "result";
	// }

}
*/