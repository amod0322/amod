package com.archcap.party.bc;

public class PartyBean {

	private PartyBasicInformationBean partyBasicInformation;
	private PartyOptionalInformationBean partyOptionalInformation;
	private PartyRolesBean partyRoles;
	private AddressBean address;

	public PartyBasicInformationBean getPartyBasicInformation() {
		return partyBasicInformation;
	}

	public void setPartyBasicInformation(PartyBasicInformationBean partyBasicInformation) {
		this.partyBasicInformation = partyBasicInformation;
	}

	public PartyOptionalInformationBean getPartyOptionalInformation() {
		return partyOptionalInformation;
	}

	public void setPartyOptionalInformation(PartyOptionalInformationBean partyOptionalInformation) {
		this.partyOptionalInformation = partyOptionalInformation;
	}

	public PartyRolesBean getPartyRoles() {
		return partyRoles;
	}

	public void setPartyRoles(PartyRolesBean partyRoles) {
		this.partyRoles = partyRoles;
	}

	public AddressBean getAddress() {
		return address;
	}

	public void setAddress(AddressBean address) {
		this.address = address;
	}

	// private Long partyId;
	// private String partyName;
	// private String partyNickName;
	// private String partyStatus;
	// private String partyType;
	// private String partyReferenceId;
	// private String archLMIReferenceId;
	// private List<String> partyRoles;
	// private String partyState;
	//

}
