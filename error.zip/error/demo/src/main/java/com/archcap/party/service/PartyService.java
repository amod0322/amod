package com.archcap.party.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.archcap.party.bc.PartyBean;
import com.archcap.party.entity.PartyEntity;

@Service
public interface PartyService {

	public PartyEntity createParty(PartyBean partyBean);

	public PartyEntity searchPartyById(Long partyId);

	public void deleteParty(Long partyId);

	public PartyEntity updateParty(Long partyId, PartyBean partyBean);

	public List<PartyEntity> readParty();

}