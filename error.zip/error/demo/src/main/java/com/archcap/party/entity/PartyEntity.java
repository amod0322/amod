package com.archcap.party.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PARTY")
public class PartyEntity {
	@Id
	@Column(name = "PARTY_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long partyId;

	@Column(name = "PARTY_NAME")
	private String partyName;

	@Column(name = "PARTY_NICKNAME")
	private String partyNickName;

	@Column(name = "PARTY_STATUS")
	private String partyStatus;

	@Column(name = "PARTY_TYPE")
	private String partyType;

	@Column(name = "PARTY_REFERENCEID")
	private String partyReferenceId;

	@Column(name = "PARTY_ARCHLMIREFERENCEID")
	private String archLMIReferenceId;

	@ManyToMany(cascade= CascadeType.MERGE)
	@JoinTable(name = "PARTY_ROLE", joinColumns = { @JoinColumn(name = "PARTY_ID") }, inverseJoinColumns = {
			@JoinColumn(name = "LONG_NAME") })
	private Set<RoleEntity> partyRoles;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PARTY_ID", unique = true)
	private AddressEntity partyAddress;

	public Set<RoleEntity> getPartyRoles() {
		return partyRoles;
	}

	public void setPartyRoles(Set<RoleEntity> partyRoles) {
		this.partyRoles = partyRoles;
	}

	public AddressEntity getPartyAddress() {
		return partyAddress;
	}

	public void setPartyAddress(AddressEntity partyAddress) {
		this.partyAddress = partyAddress;
	}

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getPartyNickName() {
		return partyNickName;
	}

	public void setPartyNickName(String partyNickName) {
		this.partyNickName = partyNickName;
	}

	public String getPartyStatus() {
		return partyStatus;
	}

	public void setPartyStatus(String partyStatus) {
		this.partyStatus = partyStatus;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	public String getPartyReferenceId() {
		return partyReferenceId;
	}

	public void setPartyReferenceId(String partyReferenceId) {
		this.partyReferenceId = partyReferenceId;
	}

	public String getArchLMIReferenceId() {
		return archLMIReferenceId;
	}

	public void setArchLMIReferenceId(String archLMIReferenceId) {
		this.archLMIReferenceId = archLMIReferenceId;
	}

}
