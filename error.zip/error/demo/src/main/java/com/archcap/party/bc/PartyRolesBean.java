package com.archcap.party.bc;

import java.util.Set;

public class PartyRolesBean {
	private Set<String> partyRoles;

	public Set<String> getPartyRoles() {
		return partyRoles;
	}

	public void setPartyRoles(Set<String> partyRoles) {
		this.partyRoles = partyRoles;
	}

}
