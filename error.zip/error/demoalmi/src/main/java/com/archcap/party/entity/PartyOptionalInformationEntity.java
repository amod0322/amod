package com.archcap.party.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OPTIONAL_INFORMATION")
public class PartyOptionalInformationEntity {
	
	@Id
	@Column(name="OPTIONALINFOID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long optionalInformatinoId;
	
	
	@Column(name = "PARTY_REFERENCEID")
	private String partyRefId;
	@Column(name = "PARTY_ARCHLMIREFERENCEID")
	private String archLMIRefId;

	public String getPartyRefId() {
		return partyRefId;
	}

	public Long getOptionalInformatinoId() {
		return optionalInformatinoId;
	}

	public void setOptionalInformatinoId(Long optionalInformatinoId) {
		this.optionalInformatinoId = optionalInformatinoId;
	}

	public void setPartyRefId(String partyRefId) {
		this.partyRefId = partyRefId;
	}

	public String getArchLMIRefId() {
		return archLMIRefId;
	}

	public void setArchLMIRefId(String archLMIRefId) {
		this.archLMIRefId = archLMIRefId;
	}

}
