package com.archcap.party.rest.controller;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.archcap.party.bc.PartyBean;
import com.archcap.party.bc.PartyRolesBean;
import com.archcap.party.entity.CustomerEntity;
import com.archcap.party.entity.PartyEntity;
import com.archcap.party.entity.RoleEntity;
import com.archcap.party.service.PartyService;

@RestController
@RequestMapping("/api")
public class PartyController {

	@Autowired
	private PartyService _partyService;

	@RequestMapping(value = "/party", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PartyBean> createParty(@RequestBody PartyBean partyBean) {

		PartyEntity partyEntity = _partyService.createParty(partyBean);

		PartyBean partySend = new PartyBean();
//		partySend.getPartyBasicInformation().setPartyId(partyEntity.getPartyBasicInformation().getPartyBasicInfoId());
		partySend.getPartyBasicInformation().setPartyName(partyEntity.getPartyBasicInformation().getPartyName());
		partySend.getPartyBasicInformation().setNickName(partyEntity.getPartyBasicInformation().getNickName());
		partySend.getPartyBasicInformation().setPartyStatus(partyEntity.getPartyBasicInformation().getPartyStatus());
		partySend.getPartyBasicInformation().setPartyType(partyEntity.getPartyBasicInformation().getPartyType());
		partySend.getPartyOptionalInformation()
				.setArchLMIRefId(partyEntity.getPartyOptionalInformation().getArchLMIRefId());
		partySend.getPartyOptionalInformation()
				.setPartyRefId(partyEntity.getPartyOptionalInformation().getPartyRefId());
		partySend.getAddress().setAttn(partyEntity.getAddress().getAttn());
		partySend.getAddress().setAddressLine1(partyEntity.getAddress().getAddressLine1());
		partySend.getAddress().setAddressLine2(partyEntity.getAddress().getAddressLine2());
		partySend.getAddress().setCity(partyEntity.getAddress().getCity());
		partySend.getAddress().setState(partyEntity.getAddress().getState());
		partySend.getAddress().setPostCode(partyEntity.getAddress().getPostCode());
		partySend.getAddress().setCountry(partyEntity.getAddress().getCountry());
		partySend.getAddress().setType(partyEntity.getAddress().getType());

		PartyRolesBean roleBean = new PartyRolesBean();
		Set<Long> roleSet = new HashSet<>();
		for (RoleEntity role : partyEntity.getPartyRoles()) {
			roleSet.add(role.getRole_type_id());

		}
		roleBean.setPartyRoles(roleSet);

		partySend.setPartyRoles(roleBean);

		return new ResponseEntity<PartyBean>(partySend, HttpStatus.CREATED);

	}
	
//	@RequestMapping(value = "/customer", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
//	public ResponseEntity<Collection<CustomerEntity>> readData() {
//		List<CustomerEntity> customerEntityList = _partyService.readParty();
//		return new ResponseEntity<Collection<CustomerEntity>>(customerEntityList, HttpStatus.OK);
//	}
	
	
	
	
	

}
