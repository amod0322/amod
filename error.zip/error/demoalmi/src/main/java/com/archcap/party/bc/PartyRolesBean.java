package com.archcap.party.bc;

import java.util.Set;

public class PartyRolesBean {
	private Set<Long> partyRoles;

	public Set<Long> getPartyRoles() {
		return partyRoles;
	}

	public void setPartyRoles(Set<Long> partyRoles) {
		this.partyRoles = partyRoles;
	}

}
