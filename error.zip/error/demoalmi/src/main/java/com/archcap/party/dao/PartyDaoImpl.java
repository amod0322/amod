package com.archcap.party.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.archcap.party.bc.PartyBean;
import com.archcap.party.entity.AddressEntity;
import com.archcap.party.entity.PartyBasicInformatioinEntity;
import com.archcap.party.entity.PartyEntity;
import com.archcap.party.entity.PartyOptionalInformationEntity;
import com.archcap.party.entity.RoleEntity;
import com.archcap.party.repository.PartyRepository;

@Repository
@Transactional
public class PartyDaoImpl implements PartyDao {

	@Autowired
	private PartyRepository _partyRepository;

	@Override
	public PartyEntity createParty(PartyBean partyBean) {
		PartyEntity partyEntity = new PartyEntity();
		PartyBasicInformatioinEntity partyBasicInfomation = new PartyBasicInformatioinEntity();
		partyEntity.setPartyBasicInformation(partyBasicInfomation);
		PartyOptionalInformationEntity partyOptionalInformation = new PartyOptionalInformationEntity();
		partyEntity.setPartyOptionalInformation(partyOptionalInformation);
		

		partyEntity.getPartyBasicInformation().setPartyName(partyBean.getPartyBasicInformation().getPartyName());

		partyEntity.getPartyBasicInformation().setNickName(partyBean.getPartyBasicInformation().getNickName());
		partyEntity.getPartyBasicInformation().setPartyStatus(partyBean.getPartyBasicInformation().getPartyStatus());
		partyEntity.getPartyBasicInformation().setPartyType(partyBean.getPartyBasicInformation().getPartyType());
		partyEntity.getPartyOptionalInformation()
				.setPartyRefId(partyBean.getPartyOptionalInformation().getPartyRefId());
		partyEntity.getPartyOptionalInformation()
				.setArchLMIRefId(partyBean.getPartyOptionalInformation().getArchLMIRefId());

		Set<RoleEntity> roleEntitySet = new HashSet<RoleEntity>();
		for (Long roles : partyBean.getPartyRoles().getPartyRoles()) {
			RoleEntity roleEntity = new RoleEntity();
			roleEntity.setRole_type_id(roles);
			switch (roles.intValue()) {
			case 1:
				roleEntity.setLong_name("Originator");
				roleEntity.setShort_name("ORG");
				break;
			case 2:
				roleEntity.setLong_name("Servicer");
				roleEntity.setShort_name("SER");
				break;
			case 3:
				roleEntity.setLong_name("Reinsurer");
				roleEntity.setShort_name("RIN");
				break;
			case 4:
				roleEntity.setLong_name("Parent Party");
				roleEntity.setShort_name("PP");
				break;

			}
			roleEntitySet.add(roleEntity);

		}

		partyEntity.setPartyRoles(roleEntitySet);

		AddressEntity addressEntity = new AddressEntity();
		addressEntity.setType(partyBean.getAddress().getType());
		addressEntity.setAttn(partyBean.getAddress().getAttn());
		addressEntity.setAddressLine1(partyBean.getAddress().getAddressLine1());
		addressEntity.setAddressLine2(partyBean.getAddress().getAddressLine2());
		addressEntity.setCity(partyBean.getAddress().getCity());
		addressEntity.setState(partyBean.getAddress().getState());
		addressEntity.setPostCode(partyBean.getAddress().getPostCode());
		addressEntity.setCountry(partyBean.getAddress().getCountry());

		partyEntity.setAddress(addressEntity);

		PartyEntity savedPartyEntity = _partyRepository.save(partyEntity);

		return savedPartyEntity;
	}

	@Override
	public PartyEntity searchPartyById(Long partyId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteParty(Long partyId) {
		// TODO Auto-generated method stub

	}

	@Override
	public PartyEntity updateParty(Long partyId, PartyBean partyBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PartyEntity> readParty() {
		// TODO Auto-generated method stub
		return null;
	}

}
