package com.archcap.party.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PARTY")
public class PartyEntity {
	@Id
	@Column(name = "PARTY_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long partyId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PARTY_ID", unique = true)
	private PartyBasicInformatioinEntity partyBasicInformation;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PARTY_ID", unique = true)
	private PartyOptionalInformationEntity partyOptionalInformation;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "PARTY_ROLE", joinColumns = { @JoinColumn(name = "PARTY_ID",referencedColumnName="PARTY_ID") }, inverseJoinColumns = {
			@JoinColumn(name = "ROLE_TYPE_ID", referencedColumnName="ROLE_TYPE_ID") })
	private Set<RoleEntity> partyRoles;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PARTY_ID", unique = true)
	private AddressEntity address;

	public Set<RoleEntity> getPartyRoles() {
		return partyRoles;
	}

	public void setPartyRoles(Set<RoleEntity> partyRoles) {
		this.partyRoles = partyRoles;
	}

	public PartyBasicInformatioinEntity getPartyBasicInformation() {
		return partyBasicInformation;
	}

	public void setPartyBasicInformation(PartyBasicInformatioinEntity partyBasicInformation) {
		this.partyBasicInformation = partyBasicInformation;
	}

	public PartyOptionalInformationEntity getPartyOptionalInformation() {
		return partyOptionalInformation;
	}

	public void setPartyOptionalInformation(PartyOptionalInformationEntity partyOptionalInformation) {
		this.partyOptionalInformation = partyOptionalInformation;
	}

	public AddressEntity getAddress() {
		return address;
	}

	public void setAddress(AddressEntity address) {
		this.address = address;
	}

	public Long getPartyId() {
		return partyId;
	}

	public void setPartyId(Long partyId) {
		this.partyId = partyId;
	}

}
