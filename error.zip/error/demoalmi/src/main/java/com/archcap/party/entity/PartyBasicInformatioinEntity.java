package com.archcap.party.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "PARTYINFO")
public class PartyBasicInformatioinEntity {
	
	@Id
	@Column(name="PARTYINFOID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long partyBasicInfoId;
	
	public Long getPartyBasicInfoId() {
		return partyBasicInfoId;
	}

	public void setPartyBasicInfoId(Long partyBasicInfoId) {
		this.partyBasicInfoId = partyBasicInfoId;
	}

	@Column(name = "PARTY_NAME")
	private String partyName;
	
	@Column(name = "PARTY_NICKNAME")
	private String nickName;
	
	@Column(name = "PARTY_STATUS")
	private String partyStatus;
	
	@Column(name = "PARTY_TYPE")
	private String partyType;


	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getPartyStatus() {
		return partyStatus;
	}

	public void setPartyStatus(String partyStatus) {
		this.partyStatus = partyStatus;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}
	
	

}
