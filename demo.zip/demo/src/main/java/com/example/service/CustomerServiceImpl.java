package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.CustomerDao;
import com.example.model.Customer;

@Service
public class CustomerServiceImpl {
	
	@Autowired
	private CustomerDao _customerDao;
	
	public Customer getCustomerById(Long customerId){
		return _customerDao.findOne(customerId);
		
	}
	
	public void save(Customer customer){
		_customerDao.save(customer);
	}
	
	public void delete(Long customerId){
		_customerDao.delete(customerId);
	}

}
