package com.example.controller;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.dao.CustomerDao;
import com.example.model.Customer;
import com.example.model.User;
import com.example.service.CustomerServiceImpl;


@Controller
public class CustomerController {
	@Autowired
	private CustomerServiceImpl _customerService;

	@RequestMapping(value="/customerinsert"
			)
	@ResponseBody
	public String createCustomer(String customerName, String loanNo, String policy, String policyStatus,
			@ModelAttribute Customer customer) {

		customer.setCustomerName(customerName);
		customer.setLoanNo(loanNo);
		customer.setPolicy(policy);
		customer.setPolicyStatus(policyStatus);
		try{
			_customerService.save(customer);
		}catch(HibernateException ex){
			
		}catch(Exception ex){
			
		}
		customer.setCustomerId(customer.getCustomerId());
		return "Customer Added successfully";

	}
	
	@RequestMapping(value="/findcustomer")
	
	public String findCustomerById(Long customerId, @ModelAttribute Customer customer){
		
		try{
			Customer customerresult= _customerService.getCustomerById(customerId);
			customer.setCustomerId(customerresult.getCustomerId());
			customer.setCustomerName(customerresult.getCustomerName());
			customer.setLoanNo(customerresult.getLoanNo());
			customer.setPolicy(customerresult.getPolicy());
			customer.setPolicyStatus(customerresult.getPolicyStatus());
			
		}catch(HibernateException ex){
			
		}catch(Exception ex){
			
		}
//		if(customer != null){
//			return "customer found successfully" + customer.getCustomerName();
//		}
//		return "customer not found successfully";
		
		return "customerfindresult";
		
	}
	
	@RequestMapping(value = "/customerdeleteid")
	@ResponseBody
	public String delete(Long customerId) {
		try {
			//Customer customer = new Customer(customerId);
			_customerService.delete(customerId);
		} catch (Exception ex) {
			return ex.getMessage();
		}
		return "User succesfully deleted!";
	}
	
	
	
	
}
