package com.example.model;

import java.util.List;

public class FDODTO {

	private Long id;//FDO id
	private String name; // long name
	private Long defaultIndicator; // for check purpose 0/1

	List<FDOVDTO> fdovDTO; // for list of fdov if exists

}
