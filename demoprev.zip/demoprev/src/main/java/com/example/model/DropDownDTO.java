package com.example.model;

public class DropDownDTO {
	
	private Long id;
	private String longName;
	private String shortName;

}
