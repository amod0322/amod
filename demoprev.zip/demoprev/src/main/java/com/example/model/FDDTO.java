package com.example.model;

import java.util.List;

public class FDDTO {

	private Long productId; // for particular product 
	private Long id; // factor dimension id
	private String name; //factor dimension id
	private String requiredinadicator; // for * mark 
	List<FDODTO> fdoDTOs; // for list of FDO if exits other wise it will be null

}
