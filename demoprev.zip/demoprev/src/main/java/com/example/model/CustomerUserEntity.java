package com.example.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="CUSTOMER_USER")
public class CustomerUserEntity {
	@EmbeddedId
	private CustomerUserId customerUserId;
	
	@Column(name="Product")
	private Long product;

}
