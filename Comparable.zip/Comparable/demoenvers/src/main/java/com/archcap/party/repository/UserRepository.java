package com.archcap.party.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.archcap.party.entity.UserEntity;
@Repository
@Transactional
public interface UserRepository extends JpaRepository<UserEntity, Long> {
	
//	@Query("select u.username,u.password, a.addressdata from User u inner join u.address a ")
//	List<Object[]> queryByhello();

}
