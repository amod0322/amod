package com.mongodb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.model.Customer;
import com.mongodb.repositories.CustomerRepository;

@RestController
@Component
@RequestMapping("/api")
public class MongoController {

	@Autowired
	private CustomerRepository customerRepository;

	@RequestMapping(value = "/insert/customer", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> insertCustomer(@RequestBody Customer customer) {
		System.out.println("create  method ");
		Customer savedCustomer = customerRepository.save(customer);

		return new ResponseEntity<>(savedCustomer, HttpStatus.OK);
	}

	@RequestMapping(value = "/find/customers", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Customer>> getCustomers() {
		System.out.println("find all  method ");
		List<Customer> customers = customerRepository.findAll();

		return new ResponseEntity<>(customers, HttpStatus.OK);
	}

	@RequestMapping(value = "/find/first-name/{firstName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> getByFirstName(@PathVariable("firstName") String firstName) {
		System.out.println("Search by first name  method ");
		Customer customer = customerRepository.findByFirstName(firstName);

		return new ResponseEntity<>(customer, HttpStatus.OK);
	}

	@RequestMapping(value = "/update/customer/{id}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> updateCustomer(@PathVariable("id") String id) {
		System.out.println("Update method ");
		Customer customer = customerRepository.findOne(id);
		customer.setFirstName("firstNameChanged");
		customer.setLastName("LastNameChanged");
		customerRepository.save(customer);

		return new ResponseEntity<>(customer, HttpStatus.OK);
	}
}
