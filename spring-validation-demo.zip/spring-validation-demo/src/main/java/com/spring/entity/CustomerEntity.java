package com.spring.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity(name="customer")
@Data
public class CustomerEntity {
	@Id
	private Long id;
	private String firstName;
	private String lastName;
	private Long age;
	private String officeName;
	private Long phoneNumber;
}
