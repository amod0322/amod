package com.spring.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.spring.annotations.OfficeValidation;

import lombok.Data;

@Data
public class Customer {
	private Long id;
	@NotNull(message = "First Name cannot be null")
	private String firstName;
	private String lastName;
	@Min(value = 3, message = "Cannot be less than {value}")
	@Max(value = 30, message = "Cannot be less than {value}")
	private Long age;
	@OfficeValidation(acceptedValues = { "HR", "CR", "HELLO" }, message = "Invalid Office Name from Customer.java")
	private String officeName;
	private Long phoneNumber;

	// @Documented
	// @Constraint(validatedBy = OfficeValidator.class)
	// @Target({ ElementType.METHOD, ElementType.FIELD })
	// @Retention(RetentionPolicy.RUNTIME)
	// public @interface OfficeNameConstraint {
	// String message() default "Invalid Office Name";
	//
	// Class<?>[] groups() default {};
	//
	// Class<? extends Payload>[] payload() default {};
	// }
}
