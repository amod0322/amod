package com.spring.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.spring.entity.CustomerEntity;
import com.spring.model.Customer;
import com.spring.model.UserBean;
import com.spring.repositories.CustomerRepository;

@RestController
@RequestMapping("/api")
public class SpringController {

	@Autowired
	private CustomerRepository customerRepository;

	@Transactional(rollbackFor = Exception.class)
	@RequestMapping(value = "/customer", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CustomerEntity> insertCustomer(@RequestBody @Valid Customer customer, BindingResult errors)
			throws Exception {
		if (errors.hasErrors()) {
			List<String> errorList = new ArrayList<>();
			List<String> fieldName = new ArrayList<>();
			errors.getAllErrors().forEach(a -> errorList.add(a.getDefaultMessage()));
			errors.getFieldErrors().forEach(fe -> {
				fieldName.add((fe.getDefaultMessage()));
			});
			return new ResponseEntity(fieldName, HttpStatus.BAD_REQUEST);
		}
		CustomerEntity customerEntity = new CustomerEntity();
		customerEntity.setId(customer.getId());
		customerEntity.setFirstName(customer.getFirstName());
		customerEntity.setLastName(customer.getLastName());
		customerEntity.setOfficeName(customer.getOfficeName());
		customerEntity.setAge(customer.getAge());
		customerEntity.setPhoneNumber(customer.getPhoneNumber());
		CustomerEntity savedCustomer = customerRepository.save(customerEntity);

		UserBean userBean = new UserBean();
		userBean.setUserId(1L);
		userBean.setUserName("Amod");
		userBean.setUserPassword("Murkute");
		RestTemplate restTemplate = new RestTemplate();
		String url = "http://localhost:8080/api/user";
		Long l = restTemplate.postForObject(url, userBean, Long.class);
		return new ResponseEntity<>(savedCustomer, HttpStatus.OK);
	}

	@RequestMapping(value = "/customers", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CustomerEntity>> getCustomers() {
		System.out.println("find all  method ");
		List<CustomerEntity> customers = customerRepository.findAll();

		return new ResponseEntity<>(customers, HttpStatus.OK);
	}

	@RequestMapping(value = "/customers/firstName/{firstName}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> getByFirstName(@PathVariable("firstName") String firstName) {
		System.out.println("Search by first name  method ");
		Customer customer = customerRepository.findByFirstName(firstName);

		return new ResponseEntity<>(customer, HttpStatus.OK);
	}

	@RequestMapping(value = "/customer/{id}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CustomerEntity> updateCustomer(@PathVariable("id") Long id) {
		System.out.println("Update method ");
		CustomerEntity customer = customerRepository.findOne(id);
		customer.setFirstName("firstNameChanged");
		customer.setLastName("LastNameChanged");
		customerRepository.save(customer);

		return new ResponseEntity<>(customer, HttpStatus.OK);
	}
}
