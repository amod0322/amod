package com.spring.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.spring.annotations.OfficeValidation;

public class OfficeValidator implements ConstraintValidator<OfficeValidation, String> {

	private List<String> validValues;

	@Override
	public void initialize(OfficeValidation ofcVal) {
		validValues = Arrays.asList(ofcVal.acceptedValues());
	}

	@Override
	public boolean isValid(String officeNameField, ConstraintValidatorContext cxt) {
		return Objects.nonNull(officeNameField) && (validValues.contains(officeNameField));
	}

}
