package com.spring.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.entity.CustomerEntity;
import com.spring.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity, Long> {
	public Customer findByFirstName(String firstName);

	public List<Customer> findByLastName(String lastName);
}
