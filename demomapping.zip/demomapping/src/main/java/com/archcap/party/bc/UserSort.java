package com.archcap.party.bc;

import java.util.Comparator;

public class UserSort implements Comparator<UserBean> {


	@Override
	public int compare(UserBean o1, UserBean o2) {
		 return o1.getUsername().compareTo(o2.getUsername());
	}

}
