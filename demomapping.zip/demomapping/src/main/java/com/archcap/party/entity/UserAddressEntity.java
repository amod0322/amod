package com.archcap.party.entity;

import javax.persistence.CascadeType;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "USER_ADDRESS")
@Audited
public class UserAddressEntity {

	@EmbeddedId
	private AddressId addresspPkId = new AddressId();

	private String userEnterValue;

	@MapsId("userId")
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "USER_ID")
	private UserEntity user;

	@MapsId("addressId")
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ADDRESS_ID")
	private AddressEntity address;

	public AddressId getAddresspPkId() {
		return addresspPkId;
	}

	public void setAddresspPkId(AddressId addresspPkId) {
		this.addresspPkId = addresspPkId;
	}

	public String getUserEnterValue() {
		return userEnterValue;
	}

	public void setUserEnterValue(String userEnterValue) {
		this.userEnterValue = userEnterValue;
	}

	public UserEntity getUser() {
		return user;
	}

	public void setUser(UserEntity user) {
		this.user = user;
	}

	public AddressEntity getAddress() {
		return address;
	}

	public void setAddress(AddressEntity address) {
		this.address = address;
	}

}
