package com.archcap.party.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.archcap.party.bc.UserBean;
import com.archcap.party.config.AppConfig;
import com.archcap.party.entity.UserEntity;
import com.archcap.party.repository.UserRepository;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	@Autowired
	private AppConfig appConfig;

	// @Autowired
	// private SessionFactory sessionFactory;

	// @Autowired
	// private SessionConfig session;
	// @Autowired
	// EntityManager entityManager;

	// Session session = entityManager.unwrap(org.hibernate.Session.class);

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserBean createUser(UserBean userBean) {
		UserEntity userEntity = new UserEntity();

		return new UserBean();
	}

	@Override
	public List<UserBean> readUser() {
		List<UserBean> userBeanList = new ArrayList<>();
		List<UserEntity> userEntityList = userRepository.findAll();
		for (UserEntity userEntity : userEntityList) {
			userBeanList.add(convertUserEntityToUserBean(userEntity));
		}
		// AuditReader reader = AuditReaderFactory.get(session);
		// UserEntity userEntity = (UserEntity) reader.find(UserEntity.class,
		// new Long(1), 1);
		// System.out.println(userEntity.getUsername() + " " +
		// userEntity.getPassword());
		//
		// List<Number> versions = reader.getRevisions(UserEntity.class, new
		// Long(1));
		// for (Number number : versions) {
		// System.out.print(number + " ");
		// }

		return userBeanList;
	}

	@Override
	public UserBean getUserById(Long userId) {
		UserEntity userEntity = userRepository.getOne(userId);
		UserBean userBean = convertUserEntityToUserBean(userEntity);
		return userBean;
	}

	UserBean convertUserEntityToUserBean(UserEntity userEntity) {
		System.out.println("Converted");
		return new UserBean();
	}

	@Override
	public UserBean updateUser(Long userId, UserBean userBean) {
		UserEntity userEntity = userRepository.findOne(userId);

		UserBean updatedUserBean = convertUserEntityToUserBean(userEntity);
		return updatedUserBean;
	}

}
