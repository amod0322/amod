 package com.archcap.party.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.archcap.party.bc.AddressBean;
import com.archcap.party.bc.UserBean;
import com.archcap.party.config.AppConfig;
import com.archcap.party.entity.AddressEntity;
import com.archcap.party.entity.UserEntity;
import com.archcap.party.repository.UserRepository;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	@Autowired
	private AppConfig appConfig;
	
//	@Autowired
//	private SessionFactory sessionFactory;
	
//	@Autowired
//	private SessionConfig session;
//	@Autowired
//	EntityManager entityManager;
	
//	Session session = entityManager.unwrap(org.hibernate.Session.class);
	
		
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public UserBean createUser(UserBean userBean) {
		UserEntity userEntity= appConfig.userEnity();
		AddressEntity addressEntity = appConfig.addressEnitity();
		userEntity.setUsername(userBean.getUsername());
		userEntity.setPassword(userBean.getPassword());
		addressEntity.setBldgName(userBean.getAddressBean().getBldgName());
		addressEntity.setStreetName(userBean.getAddressBean().getStreetName());
		userEntity.setAddress(addressEntity);
		
		UserEntity savedUserEntity = userRepository.save(userEntity);
//		Long savedUserEntity= (Long)sessionFactory.getCurrentSession().save(userEntity);
		
		UserBean savedUserBean = convertUserEntityToUserBean(savedUserEntity);
	
	
		return savedUserBean;
	}

	@Override
	public List<UserBean> readUser() {
		List<UserBean> userBeanList = new ArrayList<>();
		List<UserEntity> userEntityList = userRepository.findAll();
		for (UserEntity userEntity : userEntityList) {
			userBeanList.add(convertUserEntityToUserBean(userEntity));
		}
//		AuditReader reader = AuditReaderFactory.get(session);
//		UserEntity userEntity = (UserEntity) reader.find(UserEntity.class, new Long(1), 1);
//		System.out.println(userEntity.getUsername() + " " + userEntity.getPassword());
//		
//		List<Number> versions = reader.getRevisions(UserEntity.class, new Long(1));
//		for (Number number : versions) {
//		  System.out.print(number + " ");
//		}
		
		return userBeanList;
	}

	@Override
	public UserBean getUserById(Long userId) {
		UserEntity userEntity = userRepository.getOne(userId);
		UserBean userBean = convertUserEntityToUserBean(userEntity);
		return userBean;
	}
	
	UserBean convertUserEntityToUserBean(UserEntity userEntity){
		UserBean userBean = new UserBean();
		userBean.setId(userEntity.getId());
		userBean.setPassword(userEntity.getPassword());
		userBean.setUsername(userEntity.getUsername());
		AddressBean addressBean = new AddressBean();
		addressBean.setAddressid(userEntity.getAddress().getAddressid());
		addressBean.setBldgName(userEntity.getAddress().getBldgName());
		addressBean.setStreetName(userEntity.getAddress().getStreetName());
		userBean.setAddressBean(addressBean);
		return userBean;
	}

	@Override
	public UserBean updateUser(Long userId, UserBean userBean) {
		UserEntity userEntity=userRepository.findOne(userId);
		userEntity.setPassword(userBean.getPassword());
		userEntity.setUsername(userBean.getUsername());
		userEntity.getAddress().setAddressid(userBean.getAddressBean().getAddressid());
		userEntity.getAddress().setBldgName(userBean.getAddressBean().getBldgName());
		userEntity.getAddress().setStreetName(userBean.getAddressBean().getStreetName());
		
		UserBean updatedUserBean = convertUserEntityToUserBean(userEntity);
		return updatedUserBean;
	}

}
