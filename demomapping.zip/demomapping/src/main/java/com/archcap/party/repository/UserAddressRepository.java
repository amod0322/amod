package com.archcap.party.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.archcap.party.entity.AddressId;
import com.archcap.party.entity.UserAddressEntity;

@Repository
@Transactional
public interface UserAddressRepository extends JpaRepository<UserAddressEntity, AddressId> {

}
