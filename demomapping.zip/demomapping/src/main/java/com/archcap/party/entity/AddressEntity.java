package com.archcap.party.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.data.domain.Persistable;

@Entity
@Table(name = "address")
// @Audited
// @AttributeOverrides({ @AttributeOverride(name = "addressPkId.userId", column
// = @Column(name = "USER_ID")) })
public class AddressEntity implements Persistable<AddressId> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private AddressId addressPkId;

	@Column(name = "BLDG_NAME")
	private String bldgName;

	@Column(name = "STREET_NAME")
	private String streetName;

	public AddressId getAddressPkId() {
		return addressPkId;
	}

	public void setAddressPkId(AddressId addressPkId) {
		this.addressPkId = addressPkId;
	}

	public String getBldgName() {
		return bldgName;
	}

	public void setBldgName(String bldgName) {
		this.bldgName = bldgName;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	@Override
	public AddressId getId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return Objects.isNull(this.addressPkId.getUserId());
	}

}
