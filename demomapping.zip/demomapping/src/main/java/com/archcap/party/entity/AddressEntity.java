package com.archcap.party.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ADDRESS")
// @Audited
public class AddressEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ADDRESS_ID")
	private Long addressId;

	@Column(name = "BLDG_NAME")
	private String bldgName;

	@Column(name = "STREET_NAME")
	private String streetName;

	@OneToMany(mappedBy = "address")
	private List<UserAddressEntity> userAddress = new ArrayList<>();;

	public String getBldgName() {
		return bldgName;
	}

	public void setBldgName(String bldgName) {
		this.bldgName = bldgName;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public Long getAddressId() {
		return addressId;
	}

	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	public List<UserAddressEntity> getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(List<UserAddressEntity> userAddress) {
		this.userAddress = userAddress;
	}

}
