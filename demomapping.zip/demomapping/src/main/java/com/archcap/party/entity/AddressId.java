package com.archcap.party.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class AddressId implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "USER_ID")
	private Long userId;

	@Column(name = "ADDRESS_ID")
	private Long addressId;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getAddressId() {
		return addressId;
	}

	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

}
