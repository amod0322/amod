package com.archcap.party.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.domain.Persistable;

@Embeddable
public class AddressId implements Serializable, Persistable<Serializable> {

	private static final long serialVersionUID = 1L;

	@Column(name = "USER_ID")
	private Long userId;

	@Column(name = "ADDRESS_DATE")
	@Temporal(TemporalType.DATE)
	private Date addressDate;

	@Column(name = "USER_ENTERED_VALUE")
	private String userEnterValue;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Date getAddressDate() {
		return addressDate;
	}

	public void setAddressDate(Date addressDate) {
		this.addressDate = addressDate;
	}

	public String getUserEnterValue() {
		return userEnterValue;
	}

	public void setUserEnterValue(String userEnterValue) {
		this.userEnterValue = userEnterValue;
	}

	@Override
	public Serializable getId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return Objects.isNull(userId);
	}

}
