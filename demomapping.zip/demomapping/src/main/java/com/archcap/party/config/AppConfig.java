package com.archcap.party.config;

import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.archcap.party.bc.AddressBean;
import com.archcap.party.bc.UserBean;
import com.archcap.party.entity.AddressEntity;
import com.archcap.party.entity.UserEntity;

@Configuration
@SpringBootConfiguration
@Component
public class AppConfig {

	@Bean
	public UserBean userBean() {
		return new UserBean();
	}

	@Bean
	public AddressBean addressBean() {
		return new AddressBean();
	}

	@Bean
	public UserEntity userEnity() {
		return new UserEntity();
	}

	@Bean
	public AddressEntity addressEnitity() {
		return new AddressEntity();
	}
	
	

}
