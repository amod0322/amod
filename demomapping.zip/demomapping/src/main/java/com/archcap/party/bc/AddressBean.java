package com.archcap.party.bc;

public class AddressBean {

	private Long addressid;
	private String bldgName;
	private String streetName;
	private String userEnterValue;

	public Long getAddressid() {
		return addressid;
	}

	public String getUserEnterValue() {
		return userEnterValue;
	}

	public void setUserEnterValue(String userEnterValue) {
		this.userEnterValue = userEnterValue;
	}

	public void setAddressid(Long addressid) {
		this.addressid = addressid;
	}

	public String getBldgName() {
		return bldgName;
	}

	public void setBldgName(String bldgName) {
		this.bldgName = bldgName;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

}
