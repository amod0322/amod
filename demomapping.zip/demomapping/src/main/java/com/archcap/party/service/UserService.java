package com.archcap.party.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.archcap.party.bc.UserBean;

@Service
@Transactional
public interface UserService  {
	
	UserBean createUser(UserBean userBean);

	List<UserBean> readUser();

	UserBean getUserById(Long userId);
	
	UserBean updateUser(Long userId, UserBean userBean);

	

}
