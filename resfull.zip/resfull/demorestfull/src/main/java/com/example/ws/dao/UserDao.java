package com.example.ws.dao;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.ws.model.Person;

@Repository
@Transactional
public class UserDao  {
	
	@Autowired
	private SessionFactory _sessionFactory;
	
	private Session getSession() {
	    return _sessionFactory.getCurrentSession();
	  }
	
	 public Person getById(long id) {
		    return (Person) getSession().load(Person.class, id);
		  }

}
