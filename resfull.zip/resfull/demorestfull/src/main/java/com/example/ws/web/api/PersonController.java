package com.example.ws.web.api;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.ws.dao.UserDao;
import com.example.ws.model.Person;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class PersonController {
	
	private static Integer nextId;
	private static Map<Integer, Person> personMap;
	
	@Autowired
	private UserDao _userdao;
	
	public static Person save(Person person){
		if(personMap == null){
			personMap= new HashMap<Integer, Person>();
			nextId= 1;
		}
		person.setId(nextId);
		nextId+=1;
		personMap.put(person.getId(), person);
		return person;
		
		
	}
	
	static{
		
		Person p1= new Person();
		p1.setName("Srinivasu");
		save(p1);
		
		Person p2= new Person();
		p2.setName("Srinivasu");
		save(p2);
	}
	
	
	@RequestMapping(value = "/getpersons", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<Person>> getPersons() {
		Collection<Person> persons = personMap.values();

		return new ResponseEntity<Collection<Person>>(persons, HttpStatus.OK);

	}
	
	
	
	@RequestMapping(value="/getpersons/{id}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Person> findOne(@PathVariable("id") Integer id){
		Person person = personMap.get(id);
		
		return new ResponseEntity<Person>(person,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/getpersonsbyid/{id}", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	  @ResponseBody
	  public ResponseEntity<Person>  getByid(Integer id) {
		Person person;
	    try {
	    	person = _userdao.getById(id);
	      
	      
	    }
	    catch (Exception ex) {
	    	System.out.println(ex);
	      return null;
	    }
	    return new ResponseEntity<Person>(person,HttpStatus.OK);
	  }
	
	////////////////Testing ///////////////////////////
	
	@RequestMapping(value = "/getallpersons", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	
	public ResponseEntity<String> getallPersons() throws JsonProcessingException {
		Collection<Person> persons = personMap.values();
		
		ObjectMapper mapper = new ObjectMapper();
		//mapper.writeValue(new File("c:\\file.json"), persons);
		String jsonInString = mapper.writeValueAsString(persons);
		 String content = 
		           "<header>"
		         + "<h1><span>Url is not reachable from</span>" +  jsonInString + "</h1>"
		         + "</header>";
		
		HttpHeaders responseHeaders = new HttpHeaders();
	    responseHeaders.setContentType(MediaType.TEXT_HTML);
	    

		//return new ResponseEntity<Collection<Person>>(persons, HttpStatus.OK);
		
		return new ResponseEntity<String>(content, responseHeaders, HttpStatus.NOT_FOUND);

	}
	
	

}
