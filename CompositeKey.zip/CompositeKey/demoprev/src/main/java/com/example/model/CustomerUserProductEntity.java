package com.example.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="CUSTOMER_USER_PRODUCT")
public class CustomerUserProductEntity {

	@EmbeddedId
	private CustomerUserProductId customerUserProductId;

}
