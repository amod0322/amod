package com.example.model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Embeddable
public class CustomerUserId implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@ManyToOne
	@JoinColumn(name="CustomerID")
	private Customer customer;
	
	@ManyToOne
	@JoinColumn(name="UserID")
	private User user;
	

}
