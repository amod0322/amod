package com.example.model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

@Embeddable
public class CustomerUserProductId implements Serializable {
	private static final long serialVersionUID = 1L;

	 @ManyToOne
	    @JoinColumns({
	        @JoinColumn(name="UserID"),
	        @JoinColumn(name="CustomerID")
	    })
	private CustomerUserEntity customerUserEntity;
	
	private Long product;

}
