package com.example.model;

import java.util.List;

public class ResponseDTO {

	List<FDDTO> fdDTOList;
}
