package com.example.model;

import java.util.List;

public class FDOVDTO {

	private Long id; // FDOV id
	private String name; // long name
	private String valueSourceCode; // system or user input 
	private String decimal; // for string 
	private String systemStoredValues;
	private List<DropDownDTO> dropDownList; // for dropdownValues
	private Long length;
	private Long lowValue;
	private Long highVaue;
}
