package com.example.service;

import java.util.List;

import com.example.model.Customer;

public interface CustomerService {

	Customer getCustomerById(Long customerId);

	Customer save(Customer customer);

	void delete(Long customerId);

	Customer update(Customer customer);

	public List<Customer> selectAll();
}