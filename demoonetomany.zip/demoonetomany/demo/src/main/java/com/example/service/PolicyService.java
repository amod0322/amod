package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.model.Policy;

@Service
public interface PolicyService {

	Policy getPolicyById(Long policyNo);

	Policy save(Policy policy);

	void delete(Long policyNo);

	List<Policy> selectAll();

}