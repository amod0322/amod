package com.example.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.exception.DatabaseExcepiton;
import com.example.exception.PolicyNotFoundException;
import com.example.model.Policy;
import com.example.service.PolicyService;

@RestController
@RequestMapping("/api")
public class PolicyController {

	@Autowired
	PolicyService _policyService;

	@RequestMapping(value = "/policy/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> findPolicyById(@PathVariable("id") Long policyNo)
			throws PolicyNotFoundException, DatabaseExcepiton {
		try {
			Policy policy = _policyService.getPolicyById(policyNo);
			if (policy != null) {
				return new ResponseEntity<Object>("Policy not found with policy no " + policyNo + " in the database",
						HttpStatus.NOT_FOUND);

			} else {
				// return new ResponseEntity<Object>(policy,HttpStatus.FOUND);
				throw new PolicyNotFoundException("Policy not found with id " + policyNo);
			}
		} catch (Exception e) {
			throw new DatabaseExcepiton("Database Error");
		}
	}

	@RequestMapping(value = "/policy", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<Policy>> findAll() throws DatabaseExcepiton {
		List<Policy> policyList = new ArrayList<Policy>();
		try {
			policyList = _policyService.selectAll();
			if (policyList == null) {
				throw new PolicyNotFoundException("No Data in database");
			} else {
				return new ResponseEntity<Collection<Policy>>(policyList, HttpStatus.OK);
			}
		} catch (Exception e) {
			throw new DatabaseExcepiton("Database Error");
		}

	}

	@RequestMapping(value = "/policy/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Object> delete(@PathVariable("id") Long policyNo) throws DatabaseExcepiton {
		Policy policy = null;
		try {

			policy = _policyService.getPolicyById(policyNo);
			if (policy != null) {
				_policyService.delete(policyNo);
				return new ResponseEntity<Object>("Deleted with policy  with no " + policyNo + " successfully",
						HttpStatus.NO_CONTENT);
			} else {
				// return new ResponseEntity<Object>("Unable to delted customer
				// with id " + customerId + " not found",
				// HttpStatus.NOT_FOUND);
				throw new PolicyNotFoundException("No Data in database");

			}
		} catch (Exception e) {
			throw new DatabaseExcepiton("Database Error");
		}

	}

	@RequestMapping(value = "/policy/{id}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> update(@PathVariable("id") Long policyNo, @RequestBody Policy policy)
			throws DatabaseExcepiton {
		Policy policySearch = null;
		try {
			policySearch = _policyService.getPolicyById(policyNo);
			if (policySearch == null) {
				throw new PolicyNotFoundException("Policy Not Found");
			} else {
				policySearch.setApplicationType(policy.getApplicationType());
				policySearch.setCoverage(policy.getCoverage());
				policySearch.setCustomerName(policy.getCustomerName());
				policySearch.setCustomerNumber(policy.getCustomerNumber());
				policySearch.setLRV(policy.getLRV());
				policySearch.setPaymentPlan(policy.getPaymentPlan());
				policySearch.setStatus(policy.getStatus());
				policySearch.setTerminationReason(policy.getTerminationReason());
				policySearch.setTerminationType(policy.getTerminationType());

				Policy policysaved = _policyService.save(policySearch);
				return new ResponseEntity<Object>(policysaved, HttpStatus.OK);
			}

		} catch (Exception e) {
			throw new DatabaseExcepiton("Database Error");
		}

	}

}
