package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.model.Customer;

@Service
public interface CustomerService {

	Customer getCustomerById(Long customerId);

	Customer save(Customer customer);

	void delete(Long customerId);

	public List<Customer> selectAll();
}