package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.PolicyDao;
import com.example.model.Policy;

@Service
public class PolicyServiceImpl implements PolicyService {
	@Autowired
	PolicyDao _policyDao;

	@Override
	public Policy getPolicyById(Long policyNo) {

		return _policyDao.findOne(policyNo);

	}

	@Override
	public Policy save(Policy policy) {
		return _policyDao.save(policy);
	}

	@Override
	public void delete(Long policyNo) {
		_policyDao.delete(policyNo);
	}

	@Override
	public List<Policy> selectAll() {
		return _policyDao.findAll();
	}
}
