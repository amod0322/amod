package com.example.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.bean.CustomerBean;
import com.example.bean.PolicyBean;
import com.example.dao.CustomerDao;
import com.example.exception.CustomException;
import com.example.model.Customer;
import com.example.model.Policy;
import com.example.service.CustomerService;
import com.example.service.PolicyService;

@RestController
@RequestMapping("/api")
public class CustomerController {
//	public final Logger slf4j = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CustomerService _customerService;
	
	@Autowired
	private PolicyService _policyService;
	
	@Autowired
	private CustomerDao _customerDao;
	


	// Customer customer = new Customer();
	//
	// @RequestMapping(value = "/customerinsert")
	// @ResponseBody
	// public String createCustomer(String customerName, String loanNo, String
	// policy, String policyStatus,
	// @ModelAttribute Customer customer) {
	//
	// customer.setCustomerName(customerName);
	// customer.setLoanNo(loanNo);
	// customer.setPolicy(policy);
	// customer.setPolicyStatus(policyStatus);
	// try {
	// _customerService.save(customer);
	// } catch (HibernateException ex) {
	//
	// } catch (Exception ex) {
	//
	// }
	// customer.setCustomerId(customer.getCustomerId());
	// return "Customer Added successfully";
	//
	// }

	@RequestMapping(value = "/customer", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> createCustomer(@RequestBody CustomerBean customerBean) {
		Customer customer= new Customer();
		customer.setCustomerCity(customerBean.getCustomerCity());
		customer.setCustomerName(customerBean.getCustomerName());
		customer.setCustomerNickname(customerBean.getCustomerNickname());
		customer.setCustomerReferenceId(customerBean.getCustomerReferenceId());
		customer.setCustomerState(customerBean.getCustomerState());
		customer.setCustomerType(customerBean.getCustomerType());
		
		
		//Customer customersaved = null;
		if(customerBean.getPolicy().isEmpty()){
			System.out.println("policy not specified");
		} else{
			Set<Policy> policySet = new HashSet<>();
			
			
			
				for (PolicyBean policyBean : customerBean.getPolicy()) {
					if(policyBean.getPolicyNo()!=null ){
						Policy findPolicy =_policyService.getPolicyById(policyBean.getPolicyNo());
						if(findPolicy != null){
							policySet.add(findPolicy);
						
							
							//customer.getPolicy().remove(policy);
						}else{
							Policy policy = new Policy();
							policy.setApplicationType(policyBean.getApplicationType());
							policy.setCoverage(policyBean.getCoverage());
							policy.setCustomerName(policyBean.getCustomerName());
							policy.setCustomerNumber(policyBean.getCustomerNumber());
							policy.setLRV(policyBean.getLRV());
							policy.setPaymentPlan(policyBean.getPaymentPlan());
							policy.setPolicyNo(policyBean.getPolicyNo());
							policy.setTerminationReason(policy.getTerminationReason());
							policy.setTerminationType(policyBean.getTerminationType());
							policySet.add(policy);
						}
//						customer.getPolicy().remove(policy);
						//System.out.println("///////////////////"+policy.getPolicyNo());
						
					} else{
						Policy policy = new Policy();
						policy.setApplicationType(policyBean.getApplicationType());
						policy.setCoverage(policyBean.getCoverage());
						policy.setCustomerName(policyBean.getCustomerName());
						policy.setCustomerNumber(policyBean.getCustomerNumber());
						policy.setLRV(policyBean.getLRV());
						policy.setPaymentPlan(policyBean.getPaymentPlan());
//						policy.setPolicyNo(policyBean.getPolicyNo());
						policy.setTerminationReason(policy.getTerminationReason());
						policy.setTerminationType(policyBean.getTerminationType());
						policySet.add(policy);
					}
				}
				
				
				customer.setPolicy(policySet);
		}
		
//		System.out.println("////////////////////////"+customer.getPolicy());
			

		Customer customersaved = _customerService.save(customer);

		return new ResponseEntity<Customer>(customersaved, HttpStatus.CREATED);

	}

	// @RequestMapping(value = "/findcustomer")
	//
	// public String findCustomerById(Long customerId, @ModelAttribute Customer
	// customer) {
	//
	// try {
	// Customer customerresult = _customerService.getCustomerById(customerId);
	// customer.setCustomerId(customerresult.getCustomerId());
	// customer.setCustomerName(customerresult.getCustomerName());
	// customer.setLoanNo(customerresult.getLoanNo());
	// customer.setPolicy(customerresult.getPolicy());
	// customer.setPolicyStatus(customerresult.getPolicyStatus());
	//
	// } catch (HibernateException ex) {
	//
	// } catch (Exception ex) {
	//
	// }
	// // if(customer != null){
	// // return "customer found successfully" + customer.getCustomerName();
	// // }
	// // return "customer not found successfully";
	//
	// return "customerfindresult";
	//
	// }

	@RequestMapping(value = "/customer/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> findCustomerById(@PathVariable("id") Long customerId) throws CustomException {
		//slf4j.info("Welcome to Customer find fucntion");

		// if(customerId ==11){
		// ExceptionThrower exceptionThrower = new ExceptionThrower();
		// exceptionThrower.customerNotFoundException();
		// }

		Customer customer = _customerService.getCustomerById(customerId);
		if (customer != null) {
			return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		} else {
			return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
		}

	}

	// @RequestMapping(value = "/customerdeleteid")
	// @ResponseBody
	// public String delete(Long customerId) {
	// try {
	// // Customer customer = new Customer(customerId);
	// _customerService.delete(customerId);
	// } catch (Exception ex) {
	// return ex.getMessage();
	// }
	// return "User succesfully deleted!";
	// }

	@RequestMapping(value = "/customer/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<Object> delete(@PathVariable("id") Long customerId) {
		Customer customer = _customerService.getCustomerById(customerId);
		if (customer != null) {
			_customerService.delete(customerId);
			return new ResponseEntity<Object>("Deleted with customer id weith " + customerId + " successfully",
					HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<Object>("Unable to delted customer with id " + customerId + " not found",
					HttpStatus.NOT_FOUND);

		}

	}

	// @RequestMapping(value = "/customerupdatebyid")
	// @ResponseBody
	// public String update(Long customerId, String customerName, String loanNo,
	// String policy, String policyStatus) {
	// try {
	// Customer customer = new Customer();
	// customer.setCustomerId(customerId);
	// customer.setCustomerName(customerName);
	// customer.setLoanNo(loanNo);
	// customer.setPolicy(policy);
	// customer.setPolicyStatus(policyStatus);
	// _customerService.update(customer);
	// } catch (Exception ex) {
	// return ex.getMessage();
	// }
	// return "User succesfully updated!";
	// }

	@RequestMapping(value = "/customer/{id}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)

	public ResponseEntity<Object> update(@PathVariable("id") Long customerId, @RequestBody Customer customer) {
		Customer customerFind = null;
		try {
			customerFind = _customerService.getCustomerById(customerId);
			if (customerFind != null) {
				customerFind.setCustomerName(customer.getCustomerName());
				customerFind.setCustomerNickname(customer.getCustomerNickname());
				customerFind.setCustomerCity(customer.getCustomerCity());
				customerFind.setCustomerType(customer.getCustomerType());
				customerFind.setCustomerState(customer.getCustomerState());
				customerFind.setCustomerReferenceId(customer.getCustomerReferenceId());
				_customerService.save(customerFind);
				return new ResponseEntity<Object>(customerFind, HttpStatus.OK);
			} else {
				return new ResponseEntity<Object>(
						"Unable to update customer with id " + customerId + ". Customer not found.",
						HttpStatus.NOT_FOUND);

			}

		} catch (Exception ex) {
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
		}

	}

	// @RequestMapping(value = "/customerread")
	// public String readData(Model model) {
	// List<Customer> customerList = new ArrayList<Customer>();
	// customerList = _customerService.selectAll();
	// model.addAttribute(customerList);
	// return "customerread";
	// }

	@RequestMapping(value = "/customer", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<Customer>> readData() {
		List<Customer> customerList = new ArrayList<Customer>();
		customerList = _customerService.selectAll();
		// model.addAttribute(customerList);
		return new ResponseEntity<Collection<Customer>>(customerList, HttpStatus.OK);
	}

}
