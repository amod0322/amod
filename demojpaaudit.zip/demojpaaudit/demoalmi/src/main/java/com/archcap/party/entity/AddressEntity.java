package com.archcap.party.entity;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;

import com.archcap.party.repository.AddressAuditRepository;

@Entity
@Table(name = "address")

public class AddressEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "addressid")
	private Long addressid;

	@Column(name = "bldgname")
	private String bldgName;

	@Column(name = "streetname")
	private String streetName;
	
	@Autowired
	private transient AddressAuditRepository addressAuditRepository;

	public Long getAddressid() {
		return addressid;
	}

	public void setAddressid(Long addressid) {
		this.addressid = addressid;
	}

	public String getBldgName() {
		return bldgName;
	}

	public void setBldgName(String bldgName) {
		this.bldgName = bldgName;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	
	@PrePersist
	public void auditAddress(){
		System.out.println("INSIDE AUDITADDRESS()");
		AddressAuditEntity addressAuditEntity = new AddressAuditEntity();
		addressAuditEntity.setBldgName(this.bldgName);
		addressAuditEntity.setStreetName(this.getStreetName());
		Calendar calendar = Calendar.getInstance();
		Date now = calendar.getTime();
		addressAuditEntity.setModifiedDate(new Timestamp(now.getTime()));
		System.out.println("INSIDE AUDITADDRESS()");
		addressAuditRepository.save(addressAuditEntity);
		
	}

}
