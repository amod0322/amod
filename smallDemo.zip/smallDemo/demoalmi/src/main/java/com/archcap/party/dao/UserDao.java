package com.archcap.party.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;


import com.archcap.party.bc.UserBean;

@Repository
@Transactional
public interface UserDao {

	UserBean createUser(UserBean userBean);

	List<UserBean> readUser();

	UserBean getUserById(Long userId);
	
	UserBean updateUser(Long userId, UserBean userBean);
	

}