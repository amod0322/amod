package com.archcap.party.rest.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.archcap.party.bc.UserBean;
import com.archcap.party.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/user", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<UserBean>> readUser() {
		List<UserBean> userList = new ArrayList<>();
		userList = userService.readUser();
		return new ResponseEntity<List<UserBean>>(userList, HttpStatus.OK);
	}

	@RequestMapping(value = "/user", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserBean> createUser(@RequestBody UserBean userBean) {
		UserBean usersaved = userService.createUser(userBean);
		return new ResponseEntity<UserBean>(usersaved, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserBean> getUserById(@PathVariable("id") Long userId) {
		UserBean usersaved = userService.getUserById(userId);
		return new ResponseEntity<UserBean>(usersaved, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/user", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserBean> updateUser(@RequestBody UserBean userBean) {
		UserBean userupdated = userService.updateUser(userBean.getId(), userBean);
		return new ResponseEntity<UserBean>(userupdated, HttpStatus.OK);
	}

}
