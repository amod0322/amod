package com.archcap.party.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.archcap.party.bc.UserBean;
import com.archcap.party.dao.UserDao;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Override
	public UserBean createUser(UserBean userBean) {
		return userDao.createUser(userBean);
	}

	@Override
	public List<UserBean> readUser() {
		return userDao.readUser();
	}

	@Override
	public UserBean getUserById(Long userId) {
		return userDao.getUserById(userId);
	}

	@Override
	public UserBean updateUser(Long userId, UserBean userBean) {
		return userDao.updateUser(userId, userBean);
	}

	

}
